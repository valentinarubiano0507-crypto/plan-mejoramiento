PROYECTO: CENTRO DE FORMACION SENA

PASOS EN POWERSHELL (desde la carpeta del proyecto):
1. Comprueba Python: python --version (o py --version).
2. Crea entorno: py -m venv sedes
   Si funciona con python, puedes usar: python -m venv sedes
3. Activa: .\sedes\Scripts\Activate.ps1
   Si PowerShell bloquea la activacion, ejecuta:
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
   Luego vuelve a activar el entorno.
4. Instala Django: python -m pip install -r requirements.txt
5. Crea migraciones: python manage.py makemigrations gestion_centro
6. Sincroniza base de datos: python manage.py migrate
7. Crea administrador: python manage.py createsuperuser
8. Inicia servidor: python manage.py runserver
9. Abre http://127.0.0.1:8000/admin/

IMPORTANTE:
Este proyecto no incluye Python. Si no esta instalado o Windows no lo encuentra,
descargalo de https://www.python.org/downloads/ y marca "Add Python to PATH"
si aparece en el instalador.

Modelos incluidos:
- Sede
- AmbienteFormacion (ForeignKey a Sede: relacion 1:N)
- Instructor (ManyToManyField con AmbienteFormacion: relacion N:M)
