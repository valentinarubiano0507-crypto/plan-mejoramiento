from django.apps import AppConfig

class GestionCentroConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "gestion_centro"
    verbose_name = "Gestion del Centro SENA"
