from django.contrib import admin
from .models import Sede, AmbienteFormacion, Instructor


@admin.register(Sede)
class SedeAdmin(admin.ModelAdmin):
    list_display = ("codigo", "nombre")
    search_fields = ("codigo", "nombre")
    ordering = ("nombre",)


@admin.register(AmbienteFormacion)
class AmbienteFormacionAdmin(admin.ModelAdmin):
    list_display = ("codigo_aula", "capacidad_maxima", "sede")
    list_filter = ("sede",)
    search_fields = ("codigo_aula", "sede__nombre")
    list_select_related = ("sede",)


@admin.register(Instructor)
class InstructorAdmin(admin.ModelAdmin):
    list_display = ("documento", "nombres", "apellidos", "correo_institucional")
    search_fields = ("documento", "nombres", "apellidos", "correo_institucional")
    filter_horizontal = ("ambientes",)
