from django.db import models


class Sede(models.Model):
    codigo = models.CharField(max_length=20, unique=True)
    nombre = models.CharField(max_length=100)

    class Meta:
        verbose_name = "Sede"
        verbose_name_plural = "Sedes"
        ordering = ["nombre"]

    def __str__(self):
        return f"{self.codigo} - {self.nombre}"


class AmbienteFormacion(models.Model):
    codigo_aula = models.CharField(max_length=20, unique=True)
    capacidad_maxima = models.PositiveIntegerField()
    sede = models.ForeignKey(Sede, on_delete=models.CASCADE, related_name="ambientes")

    class Meta:
        verbose_name = "Ambiente de formacion"
        verbose_name_plural = "Ambientes de formacion"
        ordering = ["codigo_aula"]

    def __str__(self):
        return f"{self.codigo_aula} (capacidad: {self.capacidad_maxima})"


class Instructor(models.Model):
    documento = models.CharField(max_length=20, unique=True)
    nombres = models.CharField(max_length=100)
    apellidos = models.CharField(max_length=100)
    correo_institucional = models.EmailField(unique=True)
    ambientes = models.ManyToManyField(AmbienteFormacion, related_name="instructores", blank=True)

    class Meta:
        verbose_name = "Instructor"
        verbose_name_plural = "Instructores"
        ordering = ["apellidos", "nombres"]

    def __str__(self):
        return f"{self.nombres} {self.apellidos}"
